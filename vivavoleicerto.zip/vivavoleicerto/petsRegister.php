<?php
session_start();

if (!isset($_SESSION['cpf'])) { // Usando isset para evitar avisos
    header('location: /index.php'); // Corrigindo a barra para o caminho
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <title>Meus Pets</title>
    <link rel="stylesheet" href="css/petsRegister.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
</head>

<body>
    <div class="btn-back">
        <i class='bx bx-arrow-back'></i>
        <a href="mainPage.php">VOLTAR</a>
    </div>
    <div class="container">
        <div class="form-box login">
            <div class="subContainter">
            <h2>Pets</h2>
                <?php
                require_once 'src/controller/petsController.php';

                $cpf = $_SESSION['cpf'];
                $pets = petsRegistrados($cpf);

                if (!empty($pets)) {
                    foreach ($pets as $pet) {
                        echo '<div class="pet-card">';
                        echo '<a href="editarPets.php?id='.$pet['idPet'].'">' . htmlspecialchars($pet['nomePet']) . '</a>'; // Nome do pet
                        echo '<p><strong>Idade:</strong> ' . htmlspecialchars($pet['idadePet'] ?? 'N/A') . ' anos</p>'; // Idade
                        echo '<p><strong>Peso:</strong> ' . htmlspecialchars($pet['peso'] ?? 'N/A') . ' kg</p>'; // Peso
                        echo '<p><strong>Raça:</strong> ' . htmlspecialchars($pet['raca'] ?? 'N/A') . '</p>'; // Raça
                        echo '<p><strong>Sexo:</strong> ' . htmlspecialchars($pet['sexo'] ?? 'N/A') . '</p>'; // Sexo
                        echo '<p><strong>Observações:</strong> ' . htmlspecialchars($pet['obsPet'] ?? 'Nenhuma') . '</p>'; // Observações
                        echo '</div>';
                    }
                } else {
                    echo '<p>Nenhum pet encontrado.</p>';
                }
                ?>
            </div>
        </div>

        <div class="form-box register">
            <form action="src/controller/petsRegisterController.php" method="post">
                <h1>Registro de Pet</h1>
                <div class="input-box">
                    <input type="text" name="nomePet" id="" placeholder="Nome do pet" required>
                    <i class='bx bxs-dog'></i>
                </div>
                <div class="input-box">
                    <input type="number" name="idade" id="" placeholder="Idade" min="1" required>
                    <i class='bx bx-calendar'></i>
                </div>
                <div class="input-box">
                    <input type="number" name="peso" id="" placeholder="Peso em Kg" min="0" required>
                    <i class="fa-solid fa-weight-scale"></i>
                </div>
                <div class="input-box">
                    <input type="text" name="raca" id="" placeholder="Raça (qualquer animal)" required>
                    <i class='bx bxs-dog'></i>
                </div>
                <div class="input-box">
                    <input type="text" name="sexo" id="" placeholder="Macho/Femea" required>
                    <i class='bx bxs-dog'></i>
                </div>
                <div class="input-box">
                    <input type="text" name="obs" id="" placeholder="Observações (opicional)">
                    <i class='bx bx-message-alt-detail'></i>
                </div>
                <div class="input-box">
                    <input type="text" name="cpf" value="<?php echo $_SESSION['cpf']; ?>" readonly required>
                    <i class='bx bxs-id-card'></i>
                </div>
                <button type="submit" class="btn">Registrar Pet</button>
            </form>
        </div>

        <div class="toggle-box">
            <div class="toggle-panel toggle-left">
                <h1>Meus Pets</h1>
                <p class="modificado">Aqui você pode visualizar, editar e remover os pets desejados.</p>
                <button class="btn register-btn">Registrar pet</button>
            </div>
        </div>
        <div class="toggle-box">
            <div class="toggle-panel toggle-right">
                <h1>Registre seu bichinho!</h1>
                <p>Já possui uma conta?</p>
                <button class="btn login-btn">Ver meus pets</button>
            </div>
        </div>
    </div>

    <script>
        const container = document.querySelector('.container');
        const registerBtn = document.querySelector('.register-btn');
        const loginBtn = document.querySelector('.login-btn');

        registerBtn.addEventListener('click', () => {
            container.classList.add('active');
        });

        loginBtn.addEventListener('click', () => {
            container.classList.remove('active');
        });

        // Verifica o parâmetro na URL
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('register') && urlParams.get('register') === 'true') {
                container.classList.add('active');
            }
        });
    </script>
    <?php
    if (isset($_GET['cod']) && $_GET['cod'] == '100') {
        echo "<script>alert('Pet cadastrado com sucesso!');</script>";
    }

    if (isset($_GET['cod']) && $_GET['cod'] == '111') {
        echo "<script>alert('Pet excluido com sucesso!');</script>";
    }
    ?>
</body>

</html>