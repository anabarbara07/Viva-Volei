<?php
session_start();

if (!isset($_SESSION['cpf'])) { // Usando isset para evitar avisos
    header('location: /index.php'); // Corrigindo a barra para o caminho
    exit();
}

require_once 'src/controller/petsController.php'; // Certifique-se de que contém a função buscarPetsPorUsuario

$cpf = $_SESSION['cpf']; // O CPF do usuário logado
$pets = buscarPets($cpf); // Recupera os pets associados ao CPF

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Serviços</title>
    <link rel="stylesheet" href="css/servicos.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
</head>

<body>
    <div class="btn-back">
        <i class='bx bx-arrow-back'></i>
        <a href="mainPage.php">VOLTAR</a>
    </div>
    <div class="container">
        <div class="form-box login">
            <div class="subContainer">
                <?php
                require_once 'src/controller/servicosBancoController.php';

                $cpf = $_SESSION['cpf'];
                $servicos = servicosRegistrados($cpf);
                //href="editarPets.php?id='.$pet['idPet'].'"

                $petsMostrar = petsRegistrados($cpf);

                if (!empty($petsMostrar)) {
                    foreach ($petsMostrar as $pet) {
                        $nomePet = $pet['nomePet'];
                    }
                }

                if (!empty($servicos)) {
                    foreach ($servicos as $serv) {
                        $data = DateTime::createFromFormat('Y-m-d', $serv['dataServ']);
                        $dataFormatada = $data->format('d/m/Y');

                        $id = $serv['idServ'];

                        echo '<div class="pet-card">';
                        echo '<a >' . htmlspecialchars($serv['tipo']) . '</a>';
                        echo '<p><strong>Nome:</strong> ' . htmlspecialchars("$nomePet" ?? 'N/A') . '</p>';
                        echo '<p><strong>Preço:</strong> ' . htmlspecialchars('R$ ' . $serv['preco'] ?? 'N/A') . '</p>';
                        echo '<p><strong>Data:</strong> ' . htmlspecialchars("$dataFormatada" ?? 'N/A') . '</p>';
                        echo '<p><strong>Hora:</strong> ' . htmlspecialchars($serv['hora'] ?? 'N/A') . '</p>';
                        echo '<a id="excluir" href="src/controller/excluirServico.php?id='. $id .'">Excluir</a>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>Nenhum pet encontrado.</p>';
                }
                ?>
            </div>
        </div>

        <div class="form-box register">
            <form action="src/controller/servicosController.php" method="post">
                <h1>Agendar um Serviço</h1>
                <p></p>
                <div class="input-box">
                    <label for="servico"></label>
                    <select id="servico" name="servico" class="styled-select">
                        <option value="" disabled selected hidden>Selecione um serviço</option>
                        <option value="Vacina">Vacina (R$ 125 por dose)</option>
                        <option value="Consulta">Consulta (R$ 160)</option>
                        <option value="Tosa">Tosa (R$ 60)</option>
                        <option value="Banho">Banho (R$ 50)</option>
                        <option value="BanhoTosa">Banho e Tosa (R$ 90)</option>
                    </select>
                </div>

                <div class="input-box">
                    <input type="date" name="data" id="data" required>
                </div>

                <div class="input-box">
                    <select name="hora" id="hora" required>
                        <option value="" disabled selected hidden>Selecione um horário</option>
                        <!-- Opções de horário de 08:00 a 19:00 -->
                        <?php
                        for ($h = 8; $h <= 19; $h++) {
                            for ($m = 0; $m < 60; $m += 30) { // Intervalos de 30 minutos
                                $time = sprintf('%02d:%02d', $h, $m);
                                echo "<option value=\"$time\">$time</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="input-box">
                    <label for="servico">Selecione um Pet:</label>
                    <select id="pet" name="pet" class="styled-select">
                        <option value="" disabled selected hidden>Pets</option>
                        <?php
                        if (!empty($pets)) {
                            foreach ($pets as $pet) {
                                echo '<option value="' . htmlspecialchars($pet['idPet']) . '">' . htmlspecialchars($pet['nomePet']) . '</option>';
                            }
                        } else {
                            echo '<option value="" disabled>Nenhum pet encontrado</option>';
                        }
                        ?>
                    </select>

                </div>

                <button type="submit" class="btn">Agendar</button>
            </form>
        </div>

        <div class="toggle-box">
            <div class="toggle-panel toggle-left">
                <h1>Bem-Vindo!</h1>
                <p>Ainda não tem um serviço agendado?</p>
                <button class="btn register-btn">Agendar
                </button>
            </div>
        </div>
        <div class="toggle-box">
            <div class="toggle-panel toggle-right">
                <h1>Opa!</h1>
                <p>Gostaria de ver seus serviços já agendados?</p>
                <button class="btn login-btn">Serviços</button>
            </div>
        </div>
    </div>

    <script>
        const container = document.querySelector('.container');
        const registerBtn = document.querySelector('.register-btn');
        const loginBtn = document.querySelector('.login-btn');

        registerBtn.addEventListener('click', () => {
            container.classList.add('active');
        });

        loginBtn.addEventListener('click', () => {
            container.classList.remove('active');
        });

        // Verifica o parâmetro na URL
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('register') && urlParams.get('register') === 'true') {
                container.classList.add('active');
            }
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('data');
            const timeInput = document.getElementById('hora');
            const today = new Date();

            // Define a data mínima como hoje
            const minDate = today.toISOString().split('T')[0];
            dateInput.setAttribute('min', minDate);

            // Adiciona um evento para validar a data
            dateInput.addEventListener('change', function() {
                const selectedDate = new Date(this.value);
                const dayOfWeek = selectedDate.getUTCDay(); // 0 = Domingo, 6 = Sábado

                // Verifica se a data selecionada é um sábado ou domingo
                if (dayOfWeek === 0 || dayOfWeek === 6) {
                    alert('Por favor, selecione um dia útil (segunda a sexta).');
                    this.value = ''; // Limpa o campo
                }
            });

            // Adiciona um evento para validar a hora
            timeInput.addEventListener('change', function() {
                const selectedTime = this.value;
                const [hours, minutes] = selectedTime.split(':').map(Number);

                // Verifica se a hora está fora do intervalo permitido
                if (hours < 8 || hours > 19) {
                    alert('Por favor, selecione um horário entre 08:00 e 19:00.');
                    this.value = ''; // Limpa o campo
                }
            });
        });
    </script>
    <?php
        if (isset($_GET['cod']) && $_GET['cod'] == '111') {
            echo "<script>alert('Serviço excluido com sucesso!');</script>";
        }
    ?>
</body>

</html>