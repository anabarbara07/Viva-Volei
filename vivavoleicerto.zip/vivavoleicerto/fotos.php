<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeria de Fotos</title>
    
    <!-- Bootstrap e FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="css/fotos.css">
    
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-centralizar">
            <img  src="src/img/369951376_309555475108077_7449468456577851380_n-removebg-preview.png" alt="Logo" class="img-fluid logo" id="logo">
            <a href="index.php">Viva Vôlei</a>
        </div>
    </nav>

    <?php
    if (isset($_GET['cod']) && $_GET['cod'] == '109') {
        echo '<div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Pronto!</strong> Perfil excluído com sucesso!
        </div>';
    }
    ?>

    <div class="container-principal">
        <div class="conteudo-centralizado">
            <h2 class="noticiao">Galeria de Fotos</h2>
            <div class="bloco-categorias">

                <div class="categoria-foto">
                    <img src="src/img/2024.png" alt="Temporada 2024">
                    <div class="categoria-info">
                        <h4>Temporada 2024</h4>
                        <p>Momentos marcantes do ano.</p>
                    </div>
                </div>

                <div class="categoria-foto">
                    <img src="src/img/2023.png" alt="Temporada 2023">
                    <div class="categoria-info">
                        <h4>Temporada 2023</h4>
                        <p>Jogos e bastidores da temporada passada.</p>
                    </div>
                </div>

                <div class="categoria-foto">
                    <img src="src/img/lgbt.png" alt="Torneio Inclusivo">
                    <div class="categoria-info">
                        <h4>Torneio Inclusivo</h4>
                        <p>Evento especial LGBTQIA+ em junho.</p>
                    </div>
                </div>

                <div class="categoria-foto">
                    <img src="src/img/torneio.png" alt="Festival de Vôlei">
                    <div class="categoria-info">
                        <h4>Festival de Vôlei</h4>
                        <p>Festival com equipes convidadas.</p>
                    </div>
                </div>

                <div class="categoria-foto">
                    <img src="src/img/treinos.png" alt="Treinamentos">
                    <div class="categoria-info">
                        <h4>Treinamentos</h4>
                        <p>Rotina de treinos do projeto.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <p>&copy; Viva Vôlei. Todos os direitos reservados.</p>
            <p>Contato: <a href="#">seuemail@exemplo.com</a></p>
        </div>
    </footer>

    <!-- Scripts do Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
