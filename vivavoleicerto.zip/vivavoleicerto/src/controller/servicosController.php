<?php
    if($_POST) {
        require_once './servicosBancoController.php';

        session_start();

        $cpf = $_SESSION['cpf'];

        $idPet = $_POST['pet'];
        $tipo = $_POST['servico'];
        $hora = $_POST['hora'];
        $dataServ = $_POST['data'];


        if($tipo == 'Vacina')
            $preco = 125;

        if($tipo == 'Consulta')
            $preco = 160;

        if($tipo == 'Tosa')
            $preco = 60;

        if($tipo == 'Banho')
            $preco = 50;

        if($tipo == 'BanhoTosa')
            $preco = 90;

        servicosRegister($idPet, $tipo, $preco ,$hora, $dataServ, $cpf);

        header('location: \servicos.php');
}
?>