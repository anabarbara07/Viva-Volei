<?php
include_once __DIR__ . '/../ConexaoMysql.php';

function excluirPerfil($cpf)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'DELETE FROM `petshop`.`cliente` WHERE `cpf` = "' . $cpf . '"';

    $result = $con->Executar($sql);

    $con->Desconectar();

    return $result;
}

function informacoesPerfil($cpf)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT nome, dataNasc, email, endereco, senha FROM cliente WHERE cpf = "' . $cpf . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

function editPerfil($cpf, $nomeEdit, $dataNascEdit, $enderecoEdit, $emailEdit, $alterSenha)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT * FROM `petshop`.`cliente` WHERE cpf = "' . $cpf . '";';
    $result = $con->Consultar($sql);

    $user = $result->fetch_assoc();
    $nome = $user['nome'];
    $email = $user['email'];
    $endereco = $user['endereco'];
    $dataNasc = $user['dataNasc'];
    $senha = $user['senha'];


    if ($nome !== $nomeEdit) {
        $sql = 'UPDATE `petshop`.`cliente` SET `nome` = "' . $nomeEdit . '" WHERE (`cpf` = "' . $cpf . '");';
        $result = $con->Executar($sql);
    }
    if ($email !== $emailEdit) {
        $sql = 'UPDATE `petshop`.`cliente` SET `email` = "' . $emailEdit . '" WHERE (`cpf` = "' . $cpf . '");';
        $result = $con->Executar($sql);
    }

    if ($endereco !== $enderecoEdit) {
        $sql = 'UPDATE `petshop`.`cliente` SET `endereco` = "' . $enderecoEdit . '" WHERE (`cpf` = "' . $cpf . '");';
        $result = $con->Executar($sql);
    }

    if ($dataNasc !== $dataNascEdit) {
        $sql = 'UPDATE `petshop`.`cliente` SET `dataNasc` = "' . $dataNascEdit . '" WHERE (`cpf` = "' . $cpf . '");';
        $result = $con->Executar($sql);
    }

    if (!empty($alterSenha))
        if (!password_verify($alterSenha, $senha)) {

            $newSenha = password_hash($alterSenha, PASSWORD_DEFAULT);


            $sql = 'UPDATE `petshop`.`cliente` SET `senha` = "' . $newSenha . '" WHERE (`cpf` = "' . $cpf . '");';
            $result = $con->Executar($sql);
        }

        $con->Desconectar();

        return $result;
    
}
?>
