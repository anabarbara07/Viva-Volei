<?php
    require_once 'servicosBancoController.php';

    $idServico = $_GET['id'];
    $cod = $_GET['cod'];


    if($cod == 1)
    {
        echo $cod;

        excluirServico($idServico);

        header('location: ../../atPage.php?cod=111');
    }else
    {
        excluirServico($idServico);
        
        header('location: ../../servicos.php?cod=111');
    }

    
?>

