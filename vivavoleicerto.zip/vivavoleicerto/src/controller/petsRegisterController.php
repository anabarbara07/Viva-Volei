<?php
    if($_POST) {
        require_once './petsController.php';

        //$users = usersLoadAll();
        $nomePet = $_POST['nomePet'];
        $idade = $_POST['idade'];
        $peso = $_POST['peso'];
        $raca = $_POST['raca'];
        $obs = $_POST['obs'];
        $cpf = $_POST['cpf'];
        $sexo = $_POST['sexo'];

        petsRegister($nomePet, $idade, $peso, $raca, $cpf, $obs, $sexo);

        header('location: ../../petsRegister.php?cod=100');

    }
?>