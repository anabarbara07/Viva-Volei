<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Shop - PetCare</title>
  
    <style>
   body {
    background-color: #f7f7f7; /* Cor de fundo suave */
    font-family: Arial, sans-serif; /* Fonte padrão */
}

.container {
    width: 80%; /* Largura da caixa */
    max-width: 800px; /* Largura máxima */
    background-color: #e1f5fe; /* Verde água claro */
    border-radius: 10px; /* Bordas arredondadas */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Sombra */
    padding: 20px; /* Espaçamento interno */
    display: flex; /* Usar Flexbox */
    flex-direction: column; /* Organizar os itens em coluna */
    gap: 20px; /* Espaçamento entre os itens */
}

header {
    background-color:rgb(236, 238, 111); /* Lilás claro */
    padding: 20px;
    text-align: center;
    border-radius: 10px 10px 0 0; /* Bordas arredondadas no topo */
}

h1 {
    margin: 0;
    color: #fff; /* Cor do texto branco */
}

section {
    padding: 20px;
    background-color: #ffffff; /* Fundo branco para as seções */
    border-radius: 5px; /* Bordas arredondadas nas seções */
    box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1); /* Sombra leve */
}

footer {
    text-align: center;
    padding: 10px;
    background-color: #b39ddb; /* Lilás claro */
    color: #fff; /* Cor do texto branco */
    border-radius: 0 0 10px 10px; /* Bordas arredondadas na parte inferior */
}

h2 {
    color: #4a148c; /* Um tom mais escuro de lilás para os títulos */
}

p {
    color: #333; /* Cor do texto padrão */
}

ul {
    list-style-type: square; /* Estilo de lista */
    padding-left: 20px; /* Espaçamento à esquerda para a lista */
}
    </style>
</head>
<body>

<header>
    <h1>Bem-vindo a PetCare</h1>
</header>

<section id="sobre">
    <h2>Sobre Nós</h2>
    <p>A PetCare é um lugar dedicado ao bem-estar dos seus animais de estimação. Com uma equipe apaixonada e experiente, oferecemos os melhores serviços e produtos para garantir a saúde e a felicidade do seu pet.</p>
</section>

<section id="servicos">
    <h2>Serviços</h2>
    <ul>
        <li>Banho e Tosa</li>
        <li>Vacinação</li>
        <li>Consultas Veterinárias</li>
        
    </ul>
</section>



<section id="contato">
    <h2>Contato</h2>
    <p>Entre em contato conosco para mais informações:</p>
    <p>Email: PetCare.gmail.com.br</p>
    <p>Telefone: (55) 1234-5678</p>
    <p>Endereço: Rua dos Animais, 123 - Santa Maria, RS</p>
</section>

<footer>
    <p>&copy; 2024 PetCare. Todos os direitos reservados.</p>
</footer>

</body>
</html>