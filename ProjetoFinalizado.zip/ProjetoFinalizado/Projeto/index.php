<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <img src="src/img/vivavoleilogo.png" alt="Logo" class="img-fluid logo">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="sobre.php">Notícias</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php?register=true">Registrar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php
    if (isset($_GET['cod']) && $_GET['cod'] == '109') {
        echo '<div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Pronto!</strong> Perfil excluido com sucesso!
            </div>';
    }
    ?>
    <div class="containerslide">
        <div class="slider-wrapper">
            <div class="slider">
                <img id="slide-1" src="src/img/cores.png" alt="Consulta" />
                <img id="slide-2" src="src/img/cores.png" alt="Vacina" />
                <img id="slide-3" src="src/img/cores.png" alt="Banho e Tosa" />
            </div>
            <button class="slider-nav left" id="prev"><i class="fas fa-chevron-left"></i></button>
            <button class="slider-nav right" id="next"><i class="fas fa-chevron-right"></i></button>
        </div>
    </div>

    

    <hr class="my-5">

    

    <footer>
        <div class="container">
            <p>&copy; 2024 Pet Care Clínica. Todos os direitos reservados.</p>
            <p>Contato: <a href="mailto:contato@petcare.com">contato@petcare.com</a></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const sections = document.querySelectorAll('.section');
            sections.forEach((section) => {
                section.classList.add('visible');
            });

            const slider = document.querySelector('.slider');
            const slides = slider.querySelectorAll('img');
            let currentSlideIndex = 0;

            const moveLeft = () => {
                slider.scrollBy({
                    left: -slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            const moveRight = () => {
                slider.scrollBy({
                    left: slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            const prevButton = document.getElementById('prev');
            const nextButton = document.getElementById('next');
            prevButton.addEventListener('click', moveLeft);
            nextButton.addEventListener('click', moveRight);

            const autoMoveSlide = () => {
                currentSlideIndex++;
                if (currentSlideIndex >= slides.length) {
                    currentSlideIndex = 0;
                }
                slider.scrollTo({
                    left: currentSlideIndex * slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            setInterval(autoMoveSlide, 5000);
        });
    </script>
</body>

</html>
