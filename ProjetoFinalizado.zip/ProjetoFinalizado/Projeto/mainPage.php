<?php
session_start();

if (isset($_SESSION['cpf']) || isset($_SESSION['cpfAtendente'])) {
} else {
    header('location: /index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/mainPage.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
</head>

<body>
    <!--#5fa7a7 verde    #914ed5 roxo-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <img src="src/img/LogoSample_ByTailorBrands__1_-removebg-preview.png"
                alt="Logo"
                class="img-fluid logo">

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?php
                        if (!isset($_SESSION['cpfAtendente'])) {
                            echo '<a class="nav-link" href="perfil.php">Meu Perfil</a>';
                        }
                        ?>
                    </li>
                    <li>
                        <?php
                        if (isset($_SESSION['cpfAtendente'])) {
                            echo '<a class="nav-link" href="cadastroAtendente.php?register=true">Cadastrar Atendente</a>';
                        }
                        ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="src/controller/logoutController.php">Logout</a>
                    </li>

                    <li>
                        <?php
                        if (!isset($_SESSION['cpfAtendente'])) {
                            echo '<a class="btn pets my-3" href="petsRegister.php">
                                <i class="bx bxs-dog me-1" style="font-size: 1.2em;"></i>
                                Meus Pets</a>';
                        }
                        ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="containerslide">
        <div class="slider-wrapper">
            <!-- O slider em si -->
            <div class="slider">
                <img id="slide-1" src="src/img/consulta.png" alt="3D rendering of an imaginary orange planet in space" />
                <img id="slide-2" src="src/img/vacina.png" alt="3D rendering of an imaginary green planet in space" />
                <img id="slide-3" src="src/img/banhoetosa.png" alt="3D rendering of an imaginary blue planet in space" />
            </div>

            <!-- Botão de navegação à esquerda -->
            <button class="slider-nav left" id="prev">
                <i class="fas fa-chevron-left"></i> <!-- Ícone da seta para a esquerda -->
            </button>

            <!-- Botão de navegação à direita -->
            <button class="slider-nav right" id="next">
                <i class="fas fa-chevron-right"></i> <!-- Ícone da seta para a direita -->
            </button>
        </div>
    </div>

    <div class="container centralizar">
        <div>
            <style>
                h1 {
                    margin-top: -240px;
                }
            </style>
            <h1>Bem-vindo a <span class="petcare">Petcare</span>!</h1>
            <p2>Bem-vindo à Pet Care Clínica! Estamos muito felizes em tê-lo aqui. Nossa equipe dedicada
                está comprometida em oferecer o melhor cuidado para seus amigos peludos. Explore nossos
                serviços e sinta-se à vontade para entrar em contato se tiver alguma dúvida. Obrigado por nos escolher!</p2>
            <style>
                p2 {
                    font-size: 1.2em;

                }
            </style>
            <br>

            <?php
            if (isset($_SESSION['cpfAtendente'])) {
                echo '<a class="btn my-3" href="atPage.php">Serviços</a>';
            } else {
                echo '<a href="servicos.php" class="btn my-3">Serviços</a>';
            }

            ?>

            </br>
        </div>
    </div>

    <section id="sobre" class="container my-5 section feature">
        <div class="row align-items-center">
            <div class="col-md-6">
                <img src="src/img/king.png" alt="" class="img-fluid mb-3">


            </div>
            <div class="col-md-6">
                <p class="description">
                    Nosso petshop tem serviços de qualidade, nos quais oferecemos segurança e conforto, além de termos um preço que cabe no seu bolso.


                </p>
            </div>
        </div>
    </section>

    <hr class="my-5">



    <footer>
        <div class="container">
            <p>&copy; 2024 Pet Care Clínica. Todos os direitos reservados.</p>
            <p>Contato: <a href="mailto:contato@petcare.com">contato@petcare.com</a></p>
        </div>
    </footer>

    <style>
        footer {
            font-size: 0.7em;
            /* Ajuste o valor conforme necessário */
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const sections = document.querySelectorAll('.section');
            sections.forEach((section) => {
                section.classList.add('visible');
            });

            const slider = document.querySelector('.slider');
            const slides = slider.querySelectorAll('img');
            let currentSlideIndex = 0; // Índice do slide atual

            // Função para mover o slider para a esquerda
            const moveLeft = () => {
                slider.scrollBy({
                    left: -slider.offsetWidth, // Move o slider para a esquerda (tamanho da tela)
                    behavior: 'smooth' // Transição suave
                });
            };

            // Função para mover o slider para a direita
            const moveRight = () => {
                slider.scrollBy({
                    left: slider.offsetWidth, // Move o slider para a direita (tamanho da tela)
                    behavior: 'smooth' // Transição suave
                });
            };

            // Event listeners para os botões de navegação
            const prevButton = document.getElementById('prev');
            const nextButton = document.getElementById('next');
            prevButton.addEventListener('click', moveLeft);
            nextButton.addEventListener('click', moveRight);

            // Função para mover o slide automaticamente
            const autoMoveSlide = () => {
                currentSlideIndex++;
                if (currentSlideIndex >= slides.length) {
                    currentSlideIndex = 0; // Volta para o primeiro slide
                }
                slider.scrollTo({
                    left: currentSlideIndex * slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            // Chama a função de mover o slide a cada 5 segundos (5000 ms)
            setInterval(autoMoveSlide, 5000);
        });
    </script>

</body>

</html>