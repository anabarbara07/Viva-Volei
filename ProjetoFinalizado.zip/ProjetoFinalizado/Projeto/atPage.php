<?php
session_start();


if (!isset($_SESSION['cpfAtendente'])) { 
    header('location: /index.php'); 
    exit();
}


?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/atendente.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <img src="src/img/LogoSample_ByTailorBrands__1_-removebg-preview.png" alt="Logo" class="img-fluid logo">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="src/controller/logoutController.php">Logout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mainPage.php">Início</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="main-container">
        <div class="form-container">
            <div class="input-box">
                <form action="atPage.php" method="post">
                    <select name="clienteCpf" class="form-select">
                        <option value="">Selecione o CPF do cliente</option>
                        <?php
                        require_once 'src/controller/usersController.php';

                        
                        $clientes = usersFilter();
                        foreach ($clientes as $cliente) {
                            echo '<option value="' . htmlspecialchars($cliente['cpf']) . '">' . htmlspecialchars($cliente['cpf']) . '</option>';
                        }
                        ?>
                    </select>
                    <i class='bx bxs-id-card'></i>
                    <button type="submit" class="btn-buscar">Buscar</button>
                </form>
            </div>

            
            <div class="services-container">
                <p>Agendamentos: </p>
                <?php
                require_once 'src/controller/servicosBancoController.php';
                require_once 'src/controller/atendenteServController.php';

            

                $cpfCliente = $_POST['clienteCpf'] ?? null;

                

                if ($cpfCliente) {
                    $Allservicos = servicosRegistrados($cpfCliente); 
                } else {
                    $Allservicos = AllservRegistrados(); 
                }

                if (!empty($Allservicos)) {
                    foreach ($Allservicos as $Allserv) {
                        $data = DateTime::createFromFormat('Y-m-d', $Allserv['dataServ']);
                        $dataFormatada = $data->format('d/m/Y');

                        $id = $Allserv['idServ'];

                        echo '<div class="pet-card">';
                        echo '<a>' . htmlspecialchars($Allserv['tipo']) . '</a>';
                        echo '<p><strong>Preço:</strong> ' . htmlspecialchars('R$ ' . $Allserv['preco'] ?? 'N/A') . '</p>';
                        echo '<p><strong>Data:</strong> ' . htmlspecialchars("$dataFormatada" ?? 'N/A') . '</p>';
                        echo '<p><strong>Hora:</strong> ' . htmlspecialchars($Allserv['hora'] ?? 'N/A') . '</p>';
                        echo '<a id="excluir" href="src/controller/excluirServico.php?id=' . $id . '&cod=1">Excluir</a>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>Nenhum serviço encontrado.</p>';
                }
                ?>
            </div>
        </div>
    </div>

    <hr class="my-5">



    <footer>
        <div class="container">
            <p>&copy; 2024 Pet Care Clínica. Todos os direitos reservados.</p>
            <p>Contato: <a href="mailto:contato@petcare.com">contato@petcare.com</a></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <?php
    if (isset($_GET['cod']) && $_GET['cod'] == '111') {
        echo "<script>alert('Serviço excluido com sucesso!');</script>";
    }
    if (isset($_GET['cod']) && $_GET['cod'] == '103') {
        echo "<script>alert('Atendente cadastrado!');</script>";
    }
    ?>
</body>

</html>