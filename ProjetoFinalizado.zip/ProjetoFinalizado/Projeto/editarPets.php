<?php
session_start();

if (!isset($_SESSION['cpf'])) { 
    header('location: /index.php'); 
    exit();
}

require_once 'src/controller/petsController.php';

$cpf = $_SESSION['cpf'];

$idPet = $_GET['id'];
$result = detalhesPet($idPet);

if ($result->num_rows > 0) {
    
    $user = $result->fetch_assoc();
    $idPet = $user['idPet'];
    $nomePet = $user['nomePet'];
    $idade = $user['idadePet'];
    $peso = $user['peso'];
    $raca = $user['raca'];
    $sexo = $user['sexo'];
    $obs = $user['obsPet'];
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/editarPets.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
    <title>Editar Perfil de Pet</title>
</head>

<body>

    <div class="btn-back">
        <i class='bx bx-arrow-back'></i>
        <a href="petsRegister.php">VOLTAR</a>
    </div>

    <div class="container">
        <h1>Editar Perfil do Pet</h1>
        <div class="profile-info">
            <form action="src/controller/editarPerfilPET.php" method="post">

                <input type="hidden" name="idPet" value="<?= $idPet; ?>">
                
                <div class="info-box">
                    <label for="nome">Nome do Pet:</label>
                    <input type="text" id="nome" name="nome" value="<?php echo $nomePet; ?>" disabled>
                </div>

                <div class="info-box">
                    <label for="raca">Raça:</label>
                    <input type="text" id="raca" name="raca" value="<?php echo $raca; ?>" disabled>
                </div>

                <div class="info-box">
                    <label for="idade">Idade:</label>
                    <input type="number" id="idade" name="idade" value="<?php echo $idade; ?>" disabled>
                </div>

                <div class="info-box">
                    <label for="peso">Peso (kg):</label>
                    <input type="number" id="peso" name="peso" value="<?php echo $peso; ?>" disabled>
                </div>

                <div class="info-box">
                    <label for="sexo">Sexo:</label>
                    <input type="text" id="sexo" name="sexo" value="<?php echo $sexo; ?>" disabled>
                </div>

                <div class="info-box">
                    <label for="obs">Observação:</label>
                    <input type="text" id="obs" name="obs" value="<?php echo $obs; ?>" disabled>
                </div>

                <div class="info-box" id="confirmSenhaBox" style="display: none;">
                    <label for="senha">Confirmar Senha:</label>
                    <input type="password" name="confirmSenha" id="confirmSenha" placeholder="Confirme sua senha para aplicar alterações" disabled>
                    <i class="fa-regular fa-eye-slash" id="eye-confirm-senha" style="cursor: pointer;"></i>
                </div>

                <div class="button-group">
                    <button type="submit" class="btn save-btn" id="salvar" style="display: none;">Salvar</button>
                    <button type="button" class="btn cancel-btn" id="cancelar" style="display: none;">Cancelar</button>
                </div>
            </form>

            <div class="button-group">
                <button class="btn edit-btn">Editar</button>
                <button class="btn delete-btn" style="display: block;">Excluir</button>
            </div>

            <div id="overlay" class="overlay hidden"></div>
        </div>

        <div id="alert" class="alert hidden">
            <h2>Tem certeza que deseja apagar o perfil do pet?</h2>
            <p>Esta ação não pode ser desfeita.</p>
            <a id="confirmDelete" href="src/controller/excluirPerfilPet.php?id=<?= $idPet; ?>">Sim, deletar</a>
            <a id="cancelDelete">Cancelar</a>
        </div>

    </div>

    <script>
        const editBtn = document.querySelector('.edit-btn');
        const saveBtn = document.querySelector('.save-btn');
        const deleteBtn = document.querySelector('.delete-btn');
        const overlay = document.getElementById('overlay');
        const alertBox = document.getElementById('alert');
        const confirmDelete = document.getElementById('confirmDelete');
        const cancelDelete = document.getElementById('cancelDelete');
        const inputs = document.querySelectorAll('.info-box input');
        const cancelBtn = document.getElementById('cancelar');
        const container = document.querySelector('.container');
        const confirmSenhaBox = document.getElementById('confirmSenhaBox');

        editBtn.addEventListener('click', () => {
            inputs.forEach(input => input.disabled = false); 
            confirmSenhaBox.style.display = 'block'; 
            editBtn.style.display = 'none'; 
            deleteBtn.style.display = 'none'; 
            saveBtn.style.display = 'block';
            cancelBtn.style.display = 'block'; 
            container.classList.add('active'); 
        });

        cancelBtn.addEventListener('click', () => {
            container.classList.remove('active'); 
            inputs.forEach(input => {
                input.disabled = true; 
            });
            confirmSenhaBox.style.display = 'none'; 
            editBtn.style.display = 'block'; 
            deleteBtn.style.display = 'block'; 
            saveBtn.style.display = 'none'; 
            cancelBtn.style.display = 'none'; 
        });

        deleteBtn.addEventListener('click', () => {
            overlay.classList.add('active'); 
            alertBox.classList.remove('hidden'); 
        });

        cancelDelete.addEventListener('click', () => {
            overlay.classList.remove('active'); 
            alertBox.classList.add('hidden'); 
        });
    </script>

    <script>
        let eyeConfirmSenha = document.getElementById("eye-confirm-senha");
        let confirmSenha = document.getElementById("confirmSenha");

        eyeConfirmSenha.onclick = function() {
            if (confirmSenha.type === "password") {
                confirmSenha.type = "text"; 
                eyeConfirmSenha.classList.remove("fa-eye-slash"); 
                eyeConfirmSenha.classList.add("fa-eye"); 
            } else {
                confirmSenha.type = "password"; 
                eyeConfirmSenha.classList.remove("fa-eye"); 
                eyeConfirmSenha.classList.add("fa-eye-slash"); 
            }
        };
    </script>
</body>

</html>
