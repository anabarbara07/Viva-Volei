<?php
session_start();

if (!isset($_SESSION['cpf'])) { // Usando isset para evitar avisos
    header('location: /index.php'); // Corrigindo a barra para o caminho
    exit();
}

require_once 'src/controller/perfilController.php';


$cpf = $_SESSION['cpf'];
$result = informacoesPerfil($cpf);

if ($result->num_rows > 0) {
    // Fetch associative array
    $user = $result->fetch_assoc();
    $nome = $user['nome'];
    $email = $user['email'];
    $endereco = $user['endereco'];
    $dataNasc = $user['dataNasc'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/perfil.css">
    <link rel="icon" href="src/img/LogoSample_StrongPurple.png" type="image/png">
    <title>Meu Perfil</title>
</head>

<body>
    <div class="btn-back">
        <i class='bx bx-arrow-back'></i>
        <a href="mainPage.php">VOLTAR</a>
    </div>
    <div class="container">
        <h1>Meu Perfil</h1>
        <div class="profile-info">
            <form action="src/controller/editarPerfil.php" method="post">
                <div class="info-box">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" value="<?php echo $nome; ?>" disabled>
                </div>
                <div class="info-box">
                    <label for="nome">Data de nascimento:</label>
                    <input type="date" id="dataNasc" name="dataNasc" value="<?php echo $dataNasc; ?>" disabled>
                </div>
                <div class="info-box">
                    <label for="endereco">Endereço:</label>
                    <input type="text" id="endereco" name="endereco" value="<?php echo $endereco; ?>" disabled>
                </div>
                <div class="info-box">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo $email; ?>" disabled>
                </div>
                <div class="info-box">
                    <label for="senha">Senha:</label>
                    <input type="password" name="senha" id="senha-login" placeholder="Altere somente se deseja mudar a senha" disabled>
                    <i class="fa-regular fa-eye-slash" id="eye-login" style="cursor: pointer;"></i>
                </div>
                <div class="info-box" id="confirmSenhaBox" style="display: none;">
                    <label for="senha">Confirmar Senha:</label>
                    <input type="password" name="confirmSenha" id="confirmSenha" placeholder="Confirme sua senha para aplicar alterações" disabled>
                    <i class="fa-regular fa-eye-slash" id="eye-confirm-senha" style="cursor: pointer;"></i>
                </div>
                <div class="button-group">
                    <button type="submit" class="btn save-btn" id="salvar" style="display: none;">Salvar</button>
                    <button type="button" class="btn cancel-btn" id="cancelar" style="display: none;">Cancelar</button>
                </div>
            </form>
            <div class="button-group">
                <button class="btn edit-btn">Editar</button>
                <button class="btn delete-btn" style="display: block;">Excluir</button>

                <div id="overlay" class="overlay hidden"></div>
            </div>

        </div>
        <div id="alert" class="alert hidden">
            <h2>Tem certeza que deseja apagar o perfil?</h2>
            <p>Esta ação não pode ser desfeita.</p>
            <a id="confirmDelete" href="src/controller/excluirPerfil.php">Sim, deletar</a>
            <a id="cancelDelete">Cancelar</a>
        </div>
    </div>


    <script>
        const editBtn = document.querySelector('.edit-btn');
        const saveBtn = document.querySelector('.save-btn');
        const deleteBtn = document.querySelector('.delete-btn');
        const overlay = document.getElementById('overlay');
        const alertBox = document.getElementById('alert');
        const confirmDelete = document.getElementById('confirmDelete');
        const cancelDelete = document.getElementById('cancelDelete');
        const inputs = document.querySelectorAll('.info-box input');
        const confirmSenhaBox = document.getElementById('confirmSenhaBox');
        const cancelBtn = document.getElementById('cancelar');

        editBtn.addEventListener('click', () => {
            inputs.forEach(input => input.disabled = false); // Habilitar inputs
            confirmSenhaBox.style.display = 'block'; // Mostrar o campo "Confirmar Senha"
            editBtn.style.display = 'none'; // Ocultar botão "Editar"
            deleteBtn.style.display = 'none'; // Ocultar botão "Excluir"
            saveBtn.style.display = 'block'; // Mostrar botão "Salvar"
            cancelBtn.style.display = 'block'; // Mostrar botão "Cancelar"
        });

        cancelBtn.addEventListener('click', () => {
            inputs.forEach(input => {
                input.disabled = true; // Desabilitar inputs
            });
            confirmSenhaBox.style.display = 'none'; // Ocultar o campo "Confirmar Senha"
            editBtn.style.display = 'block'; // Mostrar botão "Editar"
            deleteBtn.style.display = 'block'; // Mostrar botão "Excluir"
            saveBtn.style.display = 'none'; // Ocultar botão "Salvar"
            cancelBtn.style.display = 'none'; // Ocultar botão "Cancelar"
        });



        deleteBtn.addEventListener('click', () => {
            overlay.classList.add('active'); // Adiciona a classe active
            alertBox.classList.remove('hidden'); // Remove a classe hidden
        });

        // Fechar o alerta e desfocar o fundo
        cancelDelete.addEventListener('click', () => {
            overlay.classList.remove('active'); // Remove a classe active
            alertBox.classList.add('hidden'); // Adiciona a classe hidden
        });
    </script>

    <script>
        // Altera a visibilidade da senha no campo de login
        let eyeLogin = document.getElementById("eye-login");
        let senhaLogin = document.getElementById("senha-login");

        eyeLogin.onclick = function() {
            if (senhaLogin.type === "password") {
                senhaLogin.type = "text"; // Altera o tipo do input para "text" (mostrar a senha)
                eyeLogin.classList.remove("fa-eye-slash"); // Remove o ícone de olho fechado
                eyeLogin.classList.add("fa-eye"); // Adiciona o ícone de olho aberto
            } else {
                senhaLogin.type = "password"; // Altera o tipo do input para "password" (esconder a senha)
                eyeLogin.classList.remove("fa-eye"); // Remove o ícone de olho aberto
                eyeLogin.classList.add("fa-eye-slash"); // Adiciona o ícone de olho fechado
            }
        };

        let eyeConfirmSenha = document.getElementById("eye-confirm-senha");
        let confirmSenha = document.getElementById("confirmSenha");

        eyeConfirmSenha.onclick = function() {
            if (confirmSenha.type === "password") {
                confirmSenha.type = "text"; // Altera o tipo do input para "text" (mostrar a senha)
                eyeConfirmSenha.classList.remove("fa-eye-slash"); // Remove o ícone de olho fechado
                eyeConfirmSenha.classList.add("fa-eye"); // Adiciona o ícone de olho aberto
            } else {
                confirmSenha.type = "password"; // Altera o tipo do input para "password" (esconder a senha)
                eyeConfirmSenha.classList.remove("fa-eye"); // Remove o ícone de olho aberto
                eyeConfirmSenha.classList.add("fa-eye-slash"); // Adiciona o ícone de olho fechado
            }
        };
    </script>
    <?php
    if (isset($_GET['cod']) && $_GET['cod'] == '110') {
        echo "<script>alert('Senha incorreta!');</script>";
    }

    if (isset($_GET['cod']) && $_GET['cod'] == '103') {
        echo "<script>alert('Perfil alterado com sucesso!');</script>";
    }
    ?>
</body>

</html>