<?php
    require_once 'servicosBancoController.php';

    $servicos = servicosRegistrados($cpf);

?>
