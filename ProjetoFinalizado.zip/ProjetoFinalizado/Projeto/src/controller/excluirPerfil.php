<?php
    require_once './perfilController.php';

    session_start();

    $cpf = $_SESSION['cpf'];

    excluirPerfil($cpf);
    unset($_SESSION['cpf']);

    header('location: ../../index.php?cod=109');
?>
