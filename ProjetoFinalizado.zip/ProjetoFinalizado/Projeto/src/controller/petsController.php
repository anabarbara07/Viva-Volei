<?php
include_once __DIR__ . '/../ConexaoMysql.php';

function petsRegister($nomePet, $idade, $peso, $raca, $cpf, $obs, $sexo)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'INSERT INTO pet (nomePet, idadePet, peso, raca, sexo, obsPet, donoCpf) values ("' . $nomePet . '","' . $idade . '","' . $peso . '","' . $raca . '","' . $sexo . '","' . $obs . '","' . $cpf . '")';

    $result = $con->Executar($sql);

    $con->Desconectar();

    return $result;
}


function petsRegistrados($cpf)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT * FROM pet WHERE donoCpf="' . $cpf . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

function detalhesPet($idPet)
{
    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT * FROM pet WHERE idPet = "' . $idPet . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

function editPet($idPet, $nomePetEdit, $racaEdit, $idadeEdit, $pesoEdit, $sexoEdit, $obsEdit)
{
    $con = new ConexaoMysql();
    $con->Conectar();

    // Consulta para buscar os dados do pet
    $sql = 'SELECT * FROM `petshop`.`pet` WHERE idPet = "' . $idPet . '"';
    $result = $con->Consultar($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Valores atuais do pet
        $nome = $user['nomePet'];
        $raca = $user['raca'];
        $idade = $user['idadePet'];
        $peso = $user['peso'];
        $sexo = $user['sexo'];
        $obs = $user['obsPet']; 

        // Verificando se o nome do pet foi alterado
        if ($nome !== $nomePetEdit) {
            $sql = 'UPDATE `petshop`.`pet` SET `nomePet` = "' . $nomePetEdit . '" WHERE idPet = "' . $idPet . '"';
            $result = $con->Executar($sql);
        }
        // Verificando se a raça foi alterada
        if ($raca !== $racaEdit) {
            $sql = 'UPDATE `petshop`.`pet` SET `raca` = "' . $racaEdit . '" WHERE idPet = "' . $idPet . '"';
            $result = $con->Executar($sql);
        }

        // Verificando se a idade foi alterada
        if ($idade !== $idadeEdit) {
            $sql = 'UPDATE `petshop`.`pet` SET `idadePet` = "' . $idadeEdit . '" WHERE idPet = "' . $idPet . '"';
            $result = $con->Executar($sql);
        }

        // Verificando se o peso foi alterado
        if ($peso !== $pesoEdit) {
            $sql = 'UPDATE `petshop`.`pet` SET `peso` = "' . $pesoEdit . '" WHERE idPet = "' . $idPet . '"';
            $result = $con->Executar($sql);
        }

        // Verificando se o sexo foi alterado
        if ($sexo !== $sexoEdit) {
            $sql = 'UPDATE `petshop`.`pet` SET `sexo` = "' . $sexoEdit . '" WHERE idPet = "' . $idPet . '"';
            $result = $con->Executar($sql);
        }

        // Verificando se a observação foi alterada
        if ($obs !== $obsEdit) {
            $sql = 'UPDATE `petshop`.`pet` SET `obsPet` = "' . $obsEdit . '" WHERE idPet = "' . $idPet . '"';
            $result = $con->Executar($sql);
        }
    }

    $con->Desconectar();

    return $result;
}

function excluirPet($idPet)
{
    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'DELETE FROM `petshop`.`pet` WHERE idPet = "' . $idPet . '"';

    $result = $con->Executar($sql);

    $con->Desconectar();

    return $result;
}

function buscarPets($cpf)
{
    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT nomePet, idPet FROM pet WHERE donoCpf = "' . $cpf . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

?>


