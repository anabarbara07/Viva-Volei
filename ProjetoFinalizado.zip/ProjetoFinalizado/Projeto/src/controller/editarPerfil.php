<?php
if ($_POST) {
    require_once './perfilController.php';

    session_start();

    $cpf = $_SESSION['cpf'];
    $nomeEdit = $_POST['nome'];
    $dataNascEdit = $_POST['dataNasc'];
    $enderecoEdit = $_POST['endereco'];
    $emailEdit = $_POST['email'];
    $alterSenha = $_POST['senha'];
    $senhaConfirm = $_POST['confirmSenha'];

    $result = informacoesPerfil($cpf);

    echo $alterSenha;

    if ($result->num_rows > 0) {
        // Fetch associative array
        $user = $result->fetch_assoc();
        $senhaBanco = $user['senha'];

        if (password_verify($senhaConfirm, $senhaBanco))
        {
            editPerfil($cpf, $nomeEdit, $dataNascEdit, $enderecoEdit, $emailEdit, $alterSenha);

            header('location: ../../perfil.php?cod=103');
        
        } else {
            header('location: ../../perfil.php?cod=110');
        }
    }

}
?>
