<?php
if ($_POST) {
    require_once './perfilController.php';
    require_once './petsController.php';

    session_start();

    $cpf = $_SESSION['cpf'];

    $idPet = $_POST['idPet'];
    $nomePetEdit = $_POST['nome'];
    $racaEdit = $_POST['raca'];
    $idadeEdit = $_POST['idade'];
    $pesoEdit = $_POST['peso'];
    $sexoEdit = $_POST['sexo'];
    $obsEdit = $_POST['obs'];
    $senhaConfirm = $_POST['confirmSenha'];

    $result = informacoesPerfil($cpf);

    require_once 'petsController.php';

    $pets = petsRegistrados($cpf);

    foreach ($pets as $pet) {
        $nomePet = $pet['nomePet'];
    }

    if ($result->num_rows > 0) {
        // Fetch associative array
        $user = $result->fetch_assoc();
        $senhaBanco = $user['senha'];

        if (password_verify($senhaConfirm, $senhaBanco))
        {
            editPet( $idPet, $nomePetEdit, $racaEdit, $idadeEdit, $pesoEdit, $sexoEdit, $obsEdit);

            header('location: ../../petsRegister.php');
        
        } else {
            header('location: ../../editarPets.php?nome='.$nomePet.'');
        }
    }

}
?>
