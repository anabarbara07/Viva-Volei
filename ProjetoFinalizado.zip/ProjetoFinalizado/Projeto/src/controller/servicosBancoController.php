<?php
include_once __DIR__ . '/../ConexaoMysql.php';

function servicosRegister($idPet, $tipo, $preco ,$hora, $dataServ, $cpf)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'INSERT INTO servico (tipo, preco, dataServ, hora, idPet, clienteCpf) values ("' . $tipo . '","' . $preco . '","' . $dataServ . '","' . $hora . '","' . $idPet . '","' . $cpf . '")';

    $result = $con->Executar($sql);

    $con->Desconectar();

    return $result;
}

function servicosRegistrados($cpf)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT * FROM servico WHERE clienteCpf="' . $cpf . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

function excluirServico($idServico)
{
    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'DELETE FROM `petshop`.`servico` WHERE idServ = "' . $idServico . '"';

    $result = $con->Executar($sql);

    $con->Desconectar();

    return $result;
}

?>