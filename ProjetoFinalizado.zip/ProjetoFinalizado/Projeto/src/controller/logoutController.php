<?php
    @session_start();

    unset($_SESSION['cpf']);
    unset($_SESSION['cpfAtendente']);


    header('location:\index.php');
?>