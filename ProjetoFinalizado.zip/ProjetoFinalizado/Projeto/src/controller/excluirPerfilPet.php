<?php
    require_once 'petsController.php';

    $idPet = $_GET['id'];

    excluirPet($idPet);

    header('location: ../../petsRegister.php?cod=111');
?>

